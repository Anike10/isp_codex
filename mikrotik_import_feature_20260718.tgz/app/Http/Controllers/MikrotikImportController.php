<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\InternetPackage;
use App\Models\MikrotikImportedSecret;
use App\Models\MikrotikRouter;
use App\Models\Subscription;
use App\Services\MikrotikImportService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MikrotikImportController extends Controller
{
    public function importProfiles(MikrotikRouter $mikrotikRouter, MikrotikImportService $service)
    {
        $count = $service->importProfiles($mikrotikRouter);

        return back()->with('success', "Imported {$count} MikroTik PPP profiles. New profiles were added as zero-price packages.");
    }

    public function importIpPools(MikrotikRouter $mikrotikRouter, MikrotikImportService $service)
    {
        $count = $service->importIpPools($mikrotikRouter);

        return back()->with('success', "Imported {$count} MikroTik IP pools.");
    }

    public function importSecrets(MikrotikRouter $mikrotikRouter, MikrotikImportService $service)
    {
        $count = $service->importSecrets($mikrotikRouter);

        return redirect()->route('mikrotik-routers.imported-secrets.index', $mikrotikRouter)
            ->with('success', "Imported {$count} PPPoE secrets from {$mikrotikRouter->name}.");
    }

    public function secrets(MikrotikRouter $mikrotikRouter)
    {
        return view('mikrotik_routers.imported_secrets', [
            'mikrotikRouter' => $mikrotikRouter,
            'secrets' => $mikrotikRouter->importedSecrets()->with('customer')->orderBy('name')->paginate(100),
            'profiles' => $mikrotikRouter->importedProfiles()->orderBy('name')->get(),
            'pools' => $mikrotikRouter->importedIpPools()->orderBy('name')->get(),
        ]);
    }

    public function updateSecret(Request $request, MikrotikRouter $mikrotikRouter, MikrotikImportedSecret $mikrotikImportedSecret)
    {
        abort_unless($mikrotikImportedSecret->mikrotik_router_id === $mikrotikRouter->id, 404);
        $data = $request->validate([
            'router_comment' => ['nullable', 'string'],
            'notes' => ['nullable', 'string'],
            'profile' => ['nullable', 'string', 'max:255'],
        ]);
        $mikrotikImportedSecret->update($data);

        return back()->with('success', 'Imported secret note updated.');
    }

    public function createParties(Request $request, MikrotikRouter $mikrotikRouter)
    {
        $data = $request->validate([
            'secret_ids' => ['required', 'array', 'min:1'],
            'secret_ids.*' => ['integer'],
            'never_suspend' => ['nullable', 'boolean'],
            'update_existing' => ['nullable', 'boolean'],
        ]);
        $secrets = $mikrotikRouter->importedSecrets()->whereIn('id', $data['secret_ids'])->get();
        $created = $updated = $skipped = 0;

        DB::transaction(function () use ($secrets, $mikrotikRouter, $data, &$created, &$updated, &$skipped): void {
            foreach ($secrets as $secret) {
                $customer = Customer::where('connection_id', $secret->name)->first();
                if ($customer && ! ($data['update_existing'] ?? false)) {
                    $skipped++;
                    continue;
                }

                $package = $this->packageFor($secret->profile, $mikrotikRouter);
                $note = $this->sourceNote($mikrotikRouter, $secret);
                $customerData = [
                    'name' => trim((string) ($secret->router_comment ?: $secret->name)),
                    'phone' => $customer?->phone ?: 'Not provided',
                    'connection_id' => $secret->name,
                    'mikrotik_username' => $secret->name,
                    'mikrotik_password' => $secret->password,
                    'mikrotik_router_id' => $mikrotikRouter->id,
                    'address' => $customer?->address ?: 'Imported from MikroTik '.$mikrotikRouter->name,
                    'notes' => $this->appendNote($customer?->notes, $note),
                    'status' => $secret->disabled ? 'inactive' : 'active',
                    'is_customer' => true,
                    'is_vendor' => $customer?->is_vendor ?? false,
                    'never_suspend' => (bool) ($data['never_suspend'] ?? false),
                ];
                if ($customer) {
                    $customer->update($customerData);
                    $updated++;
                } else {
                    $customer = Customer::create($customerData);
                    $created++;
                }

                $this->syncSubscription($customer, $package, $secret->disabled);
                $secret->update(['customer_id' => $customer->id]);
            }
        });

        return back()->with('success', "Party import completed: {$created} created, {$updated} updated, {$skipped} skipped.");
    }

    private function packageFor(?string $profile, MikrotikRouter $router): ?InternetPackage
    {
        if (blank($profile)) {
            return null;
        }

        return InternetPackage::firstOrCreate(
            ['mikrotik_profile' => $profile],
            ['name' => $profile, 'speed' => 'Imported profile', 'monthly_price' => 0, 'description' => 'Automatically imported from MikroTik '.$router->name.'. Set the package price before billing.', 'status' => 'active']
        );
    }

    private function syncSubscription(Customer $customer, ?InternetPackage $package, bool $disabled): void
    {
        if (! $package) {
            return;
        }

        $subscription = $customer->subscriptions()->latest('id')->first();
        $values = ['internet_package_id' => $package->id, 'start_date' => now()->toDateString(), 'status' => $disabled ? 'inactive' : 'active'];
        if ($subscription) {
            $subscription->update($values);
        } else {
            Subscription::create(['customer_id' => $customer->id, ...$values]);
        }
    }

    private function sourceNote(MikrotikRouter $router, MikrotikImportedSecret $secret): string
    {
        return 'Imported from MikroTik: '.$router->name.' ('.$router->ip_address.':'.$router->api_port.') at '.now()->format('Y-m-d H:i:s')."\nConnection ID: {$secret->name}\nProfile: ".($secret->profile ?: 'none')."\nService: ".($secret->service ?: 'none')."\nRouter comment: ".($secret->router_comment ?: 'none');
    }

    private function appendNote(?string $old, string $new): string
    {
        return trim(($old ? rtrim($old)."\n\n" : '').$new);
    }
}
