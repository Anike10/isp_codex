@extends('layouts.app')

@section('content')
<div class="topbar">
    <div>
        <h1>Edit MikroTik Router</h1>
        <div class="muted">Update RouterOS API IP, username, password, and port</div>
    </div>
    <a class="btn light" href="{{ route('mikrotik-routers.show', $mikrotikRouter) }}">Back</a>
</div>

<form method="post" action="{{ route('mikrotik-routers.update', $mikrotikRouter) }}" class="card form-grid">
    @csrf
    @method('PUT')

    <div>
        <label>Router Name</label>
        <input name="name" value="{{ old('name', $mikrotikRouter->name) }}" required>
    </div>
    <div>
        <label>IP Address</label>
        <input name="ip_address" value="{{ old('ip_address', $mikrotikRouter->ip_address) }}" required>
    </div>
    <div>
        <label>API Port</label>
        <input type="number" min="1" max="65535" name="api_port" value="{{ old('api_port', $mikrotikRouter->api_port) }}" required>
    </div>
    <div>
        <label>PPPoE Sync Interval Minutes</label>
        <input type="number" min="1" max="1440" name="pppoe_sync_interval_minutes" value="{{ old('pppoe_sync_interval_minutes', $mikrotikRouter->pppoe_sync_interval_minutes) }}" required>
        <span class="muted">How often this router should verify all PPPoE users.</span>
    </div>
    <div>
        <label>Inactive PPPoE Profile</label>
        <input name="inactive_pppoe_profile" value="{{ old('inactive_pppoe_profile', $mikrotikRouter->inactive_pppoe_profile) }}" required>
        <span class="muted">Inactive users will be moved to this profile, not disabled.</span>
    </div>
    <div>
        <label>Username</label>
        <div class="actions" style="gap:6px">
            <input id="router-username" name="username" value="{{ old('username', $mikrotikRouter->username) }}" autocomplete="off" readonly required>
            <button class="btn light" type="button" id="unlock-router-username">Change Username</button>
        </div>
        <span class="muted">Locked by default so browser autofill cannot change it accidentally.</span>
    </div>
    <div>
        <label>New Password</label>
        <input type="password" name="password">
        <span class="muted">Leave blank to keep current password.</span>
    </div>
    <div>
        <label>Status</label>
        <select name="status" required>
            <option value="active" @selected(old('status', $mikrotikRouter->status) === 'active')>Active</option>
            <option value="inactive" @selected(old('status', $mikrotikRouter->status) === 'inactive')>Inactive</option>
        </select>
    </div>
    <div class="full">
        <label>Notes</label>
        <textarea name="notes">{{ old('notes', $mikrotikRouter->notes) }}</textarea>
    </div>
    <div class="full">
        <button class="btn" type="submit">Update Router</button>
    </div>
</form>
<script>
document.getElementById('unlock-router-username')?.addEventListener('click', function () {
    const input = document.getElementById('router-username');
    input.readOnly = false;
    input.focus();
    input.select();
    this.textContent = 'Username Editable';
});
</script>
@endsection
