<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\InternetPackage;
use App\Models\MikrotikImportedIpPool;
use App\Models\MikrotikImportedProfile;
use App\Models\MikrotikImportedSecret;
use App\Models\MikrotikRouter;
use App\Services\MikrotikCustomerSyncService;
use App\Services\MikrotikImportService;
use Illuminate\Http\Request;

class MikrotikRouterDataController extends Controller
{
    public function profiles(MikrotikRouter $mikrotikRouter)
    {
        return view('mikrotik_routers.profiles', [
            'mikrotikRouter' => $mikrotikRouter,
            'profiles' => $mikrotikRouter->importedProfiles()->orderBy('name')->paginate(100),
        ]);
    }

    public function pools(MikrotikRouter $mikrotikRouter)
    {
        return view('mikrotik_routers.pools', [
            'mikrotikRouter' => $mikrotikRouter,
            'pools' => $mikrotikRouter->importedIpPools()->orderBy('name')->paginate(100),
        ]);
    }

    public function createPool(Request $request, MikrotikRouter $mikrotikRouter)
    {
        $data = $this->poolData($request);
        $pool = MikrotikImportedIpPool::create([
            ...$data,
            'mikrotik_router_id' => $mikrotikRouter->id,
            'routeros_id' => 'local-'.str()->uuid(),
            'imported_at' => now(),
        ]);

        return redirect()->route('mikrotik-routers.pools.index', $mikrotikRouter)->with('success', "IP pool {$pool->name} added locally. Use Export to MikroTik to create it on the router.");
    }

    public function updatePool(Request $request, MikrotikRouter $mikrotikRouter, MikrotikImportedIpPool $mikrotikImportedIpPool)
    {
        abort_unless($mikrotikImportedIpPool->mikrotik_router_id === $mikrotikRouter->id, 404);
        $mikrotikImportedIpPool->update($this->poolData($request));

        return back()->with('success', 'IP pool updated locally.');
    }

    public function deletePool(MikrotikRouter $mikrotikRouter, MikrotikImportedIpPool $mikrotikImportedIpPool)
    {
        abort_unless($mikrotikImportedIpPool->mikrotik_router_id === $mikrotikRouter->id, 404);
        $mikrotikImportedIpPool->delete();

        return back()->with('success', 'Local IP pool entry deleted. Router was not changed.');
    }

    public function exportPool(MikrotikRouter $mikrotikRouter, MikrotikImportedIpPool $mikrotikImportedIpPool, MikrotikImportService $service)
    {
        abort_unless($mikrotikImportedIpPool->mikrotik_router_id === $mikrotikRouter->id, 404);
        $live = collect($service->liveRecords($mikrotikRouter, '/ip/pool/print'))->firstWhere('name', $mikrotikImportedIpPool->name);
        $attributes = array_filter(['name' => $mikrotikImportedIpPool->name, 'ranges' => $mikrotikImportedIpPool->ranges, 'next-pool' => $mikrotikImportedIpPool->next_pool, 'comment' => $mikrotikImportedIpPool->source_note], fn ($value) => $value !== null && $value !== '');
        if ($live) {
            $service->write($mikrotikRouter, '/ip/pool/set', ['.id' => $live['.id'], ...$attributes]);
        } else {
            $service->write($mikrotikRouter, '/ip/pool/add', $attributes);
        }

        app(MikrotikImportService::class)->importIpPools($mikrotikRouter);
        return back()->with('success', 'IP pool exported to MikroTik and re-imported for comparison.');
    }

    public function compare(MikrotikRouter $mikrotikRouter, MikrotikImportService $service)
    {
        $liveProfiles = collect($service->liveRecords($mikrotikRouter, '/ppp/profile/print'));
        $livePools = collect($service->liveRecords($mikrotikRouter, '/ip/pool/print'));
        $liveSecrets = collect($service->liveRecords($mikrotikRouter, '/ppp/secret/print'));
        $packageProfiles = InternetPackage::query()->whereNotNull('mikrotik_profile')->orderBy('mikrotik_profile')->get();
        $customers = Customer::query()->where('mikrotik_router_id', $mikrotikRouter->id)->orderBy('connection_id')->get();

        return view('mikrotik_routers.compare', compact('mikrotikRouter', 'liveProfiles', 'livePools', 'liveSecrets', 'packageProfiles', 'customers'));
    }

    public function exportProfile(MikrotikRouter $mikrotikRouter, InternetPackage $package, MikrotikImportService $service)
    {
        $name = $package->mikrotik_profile ?: $package->name;
        $live = collect($service->liveRecords($mikrotikRouter, '/ppp/profile/print'))->firstWhere('name', $name);
        $attributes = ['name' => $name];
        if ($live) {
            $service->write($mikrotikRouter, '/ppp/profile/set', ['.id' => $live['.id'], ...$attributes]);
        } else {
            $service->write($mikrotikRouter, '/ppp/profile/add', $attributes);
        }
        $service->importProfiles($mikrotikRouter);
        return back()->with('success', "Profile {$name} exported to MikroTik.");
    }

    public function exportCustomer(MikrotikRouter $mikrotikRouter, Customer $customer, MikrotikCustomerSyncService $service)
    {
        abort_unless($customer->mikrotik_router_id === $mikrotikRouter->id, 404);
        $service->sync($customer);
        return back()->with('success', "PPPoE user {$customer->connection_id} exported to MikroTik.");
    }

    public function deleteRouterExtra(Request $request, MikrotikRouter $mikrotikRouter, MikrotikImportService $service)
    {
        $data = $request->validate(['type' => ['required', 'in:profile,pool,secret'], 'routeros_id' => ['required', 'string']]);
        $commands = ['profile' => '/ppp/profile/remove', 'pool' => '/ip/pool/remove', 'secret' => '/ppp/secret/remove'];
        $service->write($mikrotikRouter, $commands[$data['type']], ['.id' => $data['routeros_id']]);

        return back()->with('success', 'Selected extra item deleted from MikroTik.');
    }

    private function poolData(Request $request): array
    {
        return $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'ranges' => ['required', 'string'],
            'next_pool' => ['nullable', 'string', 'max:255'],
            'source_note' => ['nullable', 'string'],
        ]);
    }
}
